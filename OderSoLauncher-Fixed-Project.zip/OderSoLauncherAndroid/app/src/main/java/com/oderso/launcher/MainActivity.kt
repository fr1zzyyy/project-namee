package com.oderso.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(20, 22, 31)
    private val card = Color.rgb(42, 45, 59)
    private val purple = Color.rgb(139, 92, 246)
    private val muted = Color.rgb(185, 190, 207)
    private lateinit var body: LinearLayout
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("oderso", MODE_PRIVATE) }
    private val features = listOf("AntiSpam","ArmorHUD","Arraylist","ArrowsCount","AutoJump","BPS","Biome","BlockOutline","BlockOverlay","BossBar","BulletHell","BetterGrass","BetterTooltips","Crosshair","Coordinates","FPS","Keystrokes","MotionBlur")
    private val servers = listOf("Hive Games" to "geo.hivebedrock.network","NetherGames" to "play.nethergames.org","CubeCraft" to "mco.cubecraft.net","Zeqa" to "zeqa.net","Lifeboat" to "mco.lbsg.net","Galaxite" to "play.galaxite.net")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(18, 18, 18, 14) }
        val logo = TextView(this).apply { text = "O"; textSize = 23f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; background = shape(purple, 14); layoutParams = LinearLayout.LayoutParams(48,48) }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,0,0,0) }
        titleBox.addView(label("OderSo Launcher", 19, Color.WHITE, true))
        titleBox.addView(label("ANDROID • BEDROCK CLIENT", 10, muted, false))
        header.addView(logo); header.addView(titleBox)
        root.addView(header)
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 6, 14, 24) }
        scroll.addView(body); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(4,8,4,8); setBackgroundColor(Color.rgb(15,17,25)) }
        listOf("Главная","Функции","Версии","Скины","Настройки").forEachIndexed { i, s ->
            val b = TextView(this).apply { text = listOf("⌂\n","▦\n","◷\n","♢\n","⚙\n")[i]+s; textSize=11f; gravity=Gravity.CENTER; setTextColor(if(i==0) Color.rgb(196,181,253) else muted); setPadding(5,4,5,4); setOnClickListener { showPage(i) } }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
        showPage(0)
    }

    private fun showPage(page: Int) {
        body.removeAllViews()
        when(page) {
            0 -> {
                panel("MINECRAFT BEDROCK", "Добро пожаловать!", "Мобильный OderSo Launcher. Управляй функциями клиента, скинпаками и серверами.")
                val launch = button("▶  Запустить Minecraft PE", purple) { launchMinecraft() }
                body.addView(launch)
                body.addView(button("Импортировать скинпак (.mcpack)", card) { pickPack() })
                heading("БЫСТРЫЙ ДОСТУП")
                listOf("Функции клиента","Версии Minecraft","Скинпаки","Серверы").forEach { item(it, "Открыть") { showPage(when(it){"Функции клиента"->1;"Версии Minecraft"->2;"Скинпаки"->3;else->4}) } }
                note("Запуск открывает официальное приложение Minecraft, если оно установлено. Инжектор Windows-клиента не поддерживается Android.")
            }
            1 -> {
                heading("ФУНКЦИИ КЛИЕНТА")
                val search = EditText(this).apply { hint="⌕  Поиск функции"; setHintTextColor(muted); setTextColor(Color.WHITE); textSize=14f; setPadding(14,10,14,10); background=shape(card,12) }
                body.addView(search)
                val list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
                body.addView(list)
                fun render(q:String) {
                    list.removeAllViews()
                    features.filter { it.contains(q,true) }.forEach { name ->
                        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(12,10,12,10); background=shape(card,12) }
                        row.addView(label(name,14,Color.WHITE,true),LinearLayout.LayoutParams(0,48,1f))
                        val sw=Switch(this).apply { isChecked=prefs.getBoolean("feature_$name",false); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("feature_$name",v).apply() } }
                        row.addView(sw); val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=8; list.addView(row,lp)
                    }
                }
                render("")
                search.addTextChangedListener(SimpleWatcher { render(it) })
            }
            2 -> {
                heading("ВЕРСИИ MINECRAFT")
                item("Minecraft Bedrock для Android","Установленная версия") { launchMinecraft() }
                note("Android-версия не может устанавливать произвольные версии Bedrock как Windows UWP. Здесь можно открыть уже установленную игру.")
            }
            3 -> {
                heading("SKINPACKS")
                body.addView(button("＋  Импортировать .mcpack", purple) { pickPack() })
                note("Выбери файл .mcpack в памяти телефона. Android предложит открыть его в Minecraft, если приложение поддерживает этот тип файла.")
            }
            4 -> {
                heading("CLIENT SETTINGS")
                listOf("Уведомления","Автосохранение настроек","Подтверждение перед запуском","Тёмная тема").forEach { name ->
                    val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(12,8,12,8); background=shape(card,12) }
                    row.addView(label(name,14,Color.WHITE,false),LinearLayout.LayoutParams(0,52,1f))
                    row.addView(Switch(this).apply { isChecked=prefs.getBoolean("setting_$name",true); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("setting_$name",v).apply() } })
                    val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=8; body.addView(row,lp)
                }
                heading("SERVERS")
                servers.forEach { (name,address) -> item(name,address) { copy(address) } }
            }
        }
    }

    private fun launchMinecraft() {
        val i=packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if(i!=null) startActivity(i) else toast("Minecraft PE не найден. Установи официальную игру.")
    }
    private fun pickPack() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream","application/zip")) }
        startActivityForResult(i, 41)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==41 && resultCode==RESULT_OK) {
            val uri=data?.data ?: return
            try {
                val view=Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri,"application/octet-stream"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); setPackage("com.mojang.minecraftpe") }
                startActivity(view)
            } catch (_:Exception) { toast("Не удалось открыть файл в Minecraft. Попробуй выбрать .mcpack через файловый менеджер.") }
        }
    }
    private fun heading(s:String) { val t=label(s,13,Color.rgb(196,181,253),true); t.setPadding(3,20,3,10); body.addView(t) }
    private fun panel(k:String,h:String,d:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18); background=shape(card,18) }
        box.addView(label(k,10,Color.rgb(196,181,253),true)); box.addView(label(h,25,Color.WHITE,true)); box.addView(label(d,13,muted,false))
        val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=14; body.addView(box,lp)
    }
    private fun item(name:String, sub:String, action:()->Unit) {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(13,8,13,8); background=shape(card,12) }
        row.addView(LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; addView(label(name,14,Color.WHITE,true)); addView(label(sub,11,muted,false)) },LinearLayout.LayoutParams(0,54,1f))
        row.addView(button("Открыть", Color.rgb(70,58,100), action))
        val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=8; body.addView(row,lp)
    }
    private fun button(text:String,color:Int,action:()->Unit)=TextView(this).apply {
        this.text=text; textSize=13f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setPadding(15,12,15,12); background=shape(color,12); setOnClickListener { action() }
    }
    private fun label(text:String,size:Int,color:Int,bold:Boolean)=TextView(this).apply { this.text=text; textSize=size.toFloat(); setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD }
    private fun shape(color:Int,r: Int)=GradientDrawable().apply { setColor(color); cornerRadius=r.toFloat()*resources.displayMetrics.density; setStroke(1,Color.argb(45,220,225,245)) }
    private fun note(s:String) { val t=label(s,11,muted,false); t.setPadding(4,16,4,8); body.addView(t) }
    private fun toast(s:String) = Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun copy(s:String) { val cb=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager; cb.setPrimaryClip(android.content.ClipData.newPlainText("server",s)); toast("Адрес скопирован: $s") }
}
