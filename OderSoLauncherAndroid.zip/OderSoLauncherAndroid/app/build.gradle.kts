plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.oderso.launcher"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.oderso.launcher"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
